![]()
<p align="center">
  <img src="https://cdn.discordapp.com/attachments/521438182311460879/642999634750603274/CTC-Editor.fw.png">
</p>
Blender CTC Import-Exporter and Tooling for Monster Hunter World

# Installation  
As any other blender plugin. Download the zip of the project. Create a folder in your blender addon folder and drag the files in the zip there.

# Author
* **AsteriskAmpersand/\*&**

# Acknowledgements
* **UberGrainy** - For starting the research into the structure of the CTC and CCL files. - [UberGrainy's Mods Page] (https://www.nexusmods.com/monsterhunterworld/users/3124030?tab=user+files)
* **Karbon** - For experimental and theoretical research in the structure of the CTC and CCL files. - [Karbon's Mods Page] (https://www.nexusmods.com/monsterhunterworld/users/2587193?tab=user+files)
* **Statyk** - For practical experimentation on CTC and CCL files. - [Statyk Modding Stream](https://www.twitch.tv/zstatykz) and [Statyk's Mods Page](https://www.nexusmods.com/monsterhunterworld/users/58005106?tab=user+files)

![](https://cdn.discordapp.com/attachments/521438182311460879/642991117901758465/unknown.png)
