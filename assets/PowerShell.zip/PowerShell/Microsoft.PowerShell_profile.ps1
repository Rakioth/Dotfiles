# Load Prompt Config
$ompConfig = Join-Path $PSScriptRoot ".\raks.omp.json"
oh-my-posh init pwsh --config $ompConfig | Invoke-Expression

# Terminal-Icons
Import-Module -Name Terminal-Icons

# PSReadLine
Set-PSReadLineOption -EditMode Emacs
Set-PSReadLineOption -BellStyle None
Set-PSReadLineOption -PredictionSource History
Set-PSReadLineOption -PredictionViewStyle ListView

# Alias
Set-Alias c clear
Set-Alias g git
Set-Alias v nvim
Set-Alias n notepad
Set-Alias e explorer

# Utilities
function ..   { Set-Location .. }
function ...  { Set-Location ..\.. }
function .... { Set-Location ..\..\.. }
function idea { Set-Location D:\IdeaProjects }
function ll   { Get-ChildItem -Path $pwd -File }

function touch($file) {
	"" | Out-File $file -Encoding ASCII
}
function pgrep($name) {
	Get-Process *$name*
}
function pkill($name) {
	Get-Process $name -ErrorAction SilentlyContinue | Stop-Process
}
function which($command) {
    Get-Command $command -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Path -ErrorAction SilentlyContinue
}
function unzip($file) {
	if (!(Test-Path $file)) { return }
	$folder = Join-Path (Split-Path -Path $file -Parent) (Get-Item $file).Basename
	Expand-7Zip -ArchiveFileName $file -TargetPath $folder -ErrorAction SilentlyContinue
}
function find-file($name) {
	Get-ChildItem -Recurse -Filter "*${name}*" -ErrorAction SilentlyContinue | ForEach-Object {
		Write-Output "${_}"
	}
}
function grep($regex, $dir) {
	if ($dir) {
		Get-ChildItem $dir | Select-String $regex
		return
	}
	$input | Select-String $regex
}